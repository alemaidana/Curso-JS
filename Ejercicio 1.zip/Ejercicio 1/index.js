//Mensaje de bienvenida

console.log("Hola, este es mi primer ejercicio con Node en el mejor Bootcamp de programación del mundo");

//
